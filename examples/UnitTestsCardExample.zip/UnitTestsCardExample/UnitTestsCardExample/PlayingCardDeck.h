//
//  PlayingCardDeck.h
//  UnitTestsCardExample
//
//  Created by Stephan B Wessels on 1/23/14.
//  Copyright (c) 2014 Plum Street Software. All rights reserved.
//

#import "Deck.h"

@interface PlayingCardDeck : Deck

@end
