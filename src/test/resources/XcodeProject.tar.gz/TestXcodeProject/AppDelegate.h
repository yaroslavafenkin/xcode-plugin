//
//  AppDelegate.h
//  TestXcodeProject
//
//  Created by 高橋 和秀 on 2018/03/02.
//  Copyright © 2018年 Hoge2Network. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

